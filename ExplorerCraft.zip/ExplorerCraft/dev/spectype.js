/*
var BLOCK_RENDER_SLAB = Block.createSpecialType({
     rendertype: 50
});
*/
var BLOCK_RENDER_STAIRS = Block.createSpecialType({
     rendertype: 10,
     base: 67
});
