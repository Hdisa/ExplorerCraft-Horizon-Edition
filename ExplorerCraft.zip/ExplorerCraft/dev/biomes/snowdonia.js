var snowdoniaBiome = new CustomBiome("snowdonia")
// цвет неба
.setSkyColor(39259)
// цвет травы
.setGrassColor(39259)
// цвет листвы
.setFoliageColor(39259)
// поверхностный блок
.setCoverBlock(2, 0)
// слой блоков под поверхностью
.setSurfaceBlock(3, 0)
// блок заливки под поверхностным слоем
.setFillingBlock(1, 0);
Callback.addCallback("GenerateBiomeMap", function(x, z, rand, dimensionId, chunkSeed, worldSeed) {
(x *= 16, z *= 16);
// проходка по блокам чанка
for (var xs = x; xs < x + 26; xs++)
for (var zs = z; zs < z + 26; zs++)
// генерация случайного шума на основе сида и текущих координат
if (GenerationUtils.getPerlinNoise(xs, 0, zs, worldSeed, 0.0225, 3) < 0.3)
// установка биома (любого) на координаты
World.setBiomeMap(xs, zs, snowdoniaBiome.id);
});