//sword

IDRegistry.genItemID("rubySword");
Item.createItem("rubySword", "Ruby Sword", {name: "ruby_sword", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("ruby_sword", {durability: 451, level: 4, efficiency: 8, damage: 7, enchantability: 14});
ToolAPI.setTool(ItemID.rubySword, "ruby_sword", ToolType.sword);

Recipes.addShaped({id: ItemID.rubySword, count: 1, data: 0}, [
    "a",
    "a",
    "b"
], ["a", ItemID.ruby, 0, "b", 280, 0]);

//shovel

IDRegistry.genItemID("rubyShovel");
Item.createItem("rubyShovel", "Ruby Shovel", {name: "ruby_shovel", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("ruby_shovel", {durability: 451, level: 4, efficiency: 8, damage: 5.5, enchantability: 14});
ToolAPI.setTool(ItemID.rubyShovel, "ruby_shovel", ToolType.shovel);

Recipes.addShaped({id: ItemID.rubyShovel, count: 1, data: 0}, [
    "a",
    "b",
    "b"
], ["a", ItemID.ruby, 0, "b", 280, 0]);

//pickaxe

IDRegistry.genItemID("rubyPickaxe");
Item.createItem("rubyPickaxe", "Ruby Pickaxe", {name: "ruby_pickaxe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("ruby_pickaxe", {durability: 451, level: 4, efficiency: 8, damage: 5, enchantability: 14});
ToolAPI.setTool(ItemID.rubyPickaxe, "ruby_pickaxe", ToolType.pickaxe);

Recipes.addShaped({id: ItemID.rubyPickaxe, count: 1, data: 0}, [
    "aaa",
    " b ",
    " b "
], ["a", ItemID.ruby, 0,  "b", 280, 0]);

//axe

IDRegistry.genItemID("rubyAxe");
Item.createItem("rubyAxe", "Ruby Axe", {name: "ruby_axe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("ruby_axe", {durability: 451, level: 4, efficiency: 8, damage: 9, enchantability: 14});
ToolAPI.setTool(ItemID.rubyAxe, "ruby_axe", ToolType.axe);

Recipes.addShaped({id: ItemID.rubyAxe, count: 1, data: 0}, [
    "aa",
    "ab",
    " b"
], ['a', ItemID.ruby, 0, 'b', 280, 0]);

//hoe

IDRegistry.genItemID("rubyHoe");
Item.createItem("rubyHoe", "Ruby Hoe", {name: "ruby_hoe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("ruby_hoe", {durability: 451, level: 4, efficiency: 8, damage: 1, enchantability: 14});
ToolAPI.setTool(ItemID.rubyHoe, "ruby_hoe", ToolType.hoe);

Recipes.addShaped({id: ItemID.rubyHoe, count: 1, data: 0}, [
    "aa",
    " b",
    " b"
], ['a', ItemID.ruby, 0, 'b', 280, 0]);