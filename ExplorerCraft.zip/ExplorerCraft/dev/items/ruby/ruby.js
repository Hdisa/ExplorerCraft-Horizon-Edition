IDRegistry.genItemID("ruby");
Item.createItem("ruby", "Ruby", { name: "ruby", meta: 0});