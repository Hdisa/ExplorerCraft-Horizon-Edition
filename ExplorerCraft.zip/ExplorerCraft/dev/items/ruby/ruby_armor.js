IDRegistry.genItemID("rubyHelmet");
IDRegistry.genItemID("rubyChestplate");
IDRegistry.genItemID("rubyLeggings");
IDRegistry.genItemID("rubyBoots");

Item.createArmorItem("rubyHelmet", "Ruby Helmet", {name: "ruby_helmet"}, {type: "helmet", armor: 5, durability: 364, texture: "armor/ruby_layer_1.png"});
Item.createArmorItem("rubyChestplate", "Ruby Chestplate", {name: "ruby_chestplate"}, {type: "chestplate", armor: 7, durability: 529, texture: "armor/ruby_layer_1.png"});
Item.createArmorItem("rubyLeggings", "Ruby Leggings", {name: "ruby_leggings"}, {type: "leggings", armor: 7, durability: 496, texture: "armor/ruby_layer_2.png"});
Item.createArmorItem("rubyBoots", "Ruby Boots", {name: "ruby_boots"}, {type: "boots", armor: 5, durability: 430, texture: "armor/ruby_layer_1.png"});

Recipes.addShaped({id: ItemID.rubyHelmet, count: 1, data: 0}, [
    "xxx",
    "x x",
    "   "
], ["x", ItemID.ruby, 0]);

Recipes.addShaped({id: ItemID.rubyChestplate, count: 1, data: 0}, [
    "x x",
    "xxx",
    "xxx"
], ["x", ItemID.ruby, 0]);

Recipes.addShaped({id: ItemID.rubyLeggings, count: 1, data: 0}, [
    "xxx",
    "x x",
    "x x"
], ["x", ItemID.ruby, 0]);

Recipes.addShaped({id: ItemID.rubyBoots, count: 1, data: 0}, [
    "   ",
    "x x",
    "x x"
], ["x", ItemID.ruby, 0]);