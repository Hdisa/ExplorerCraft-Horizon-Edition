//sword

IDRegistry.genItemID("jadeSword");
Item.createItem("jadeSword", "Jade Sword", {name: "jade_sword", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("jade_sword", {durability: 1101, level: 4, efficiency: 8, damage: 7, enchantability: 14});
ToolAPI.setTool(ItemID.jadeSword, "jade_sword", ToolType.sword);

Recipes.addShaped({id: ItemID.jadeSword, count: 1, data: 0}, [
    "a",
    "a",
    "b"
], ["a", ItemID.jade, 0, "b", 280, 0]);

//shovel

IDRegistry.genItemID("jadeShovel");
Item.createItem("jadeShovel", "Jade Shovel", {name: "jade_shovel", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("jade_shovel", {durability: 1101, level: 4, efficiency: 8, damage: 5.5, enchantability: 14});
ToolAPI.setTool(ItemID.jadeShovel, "jade_shovel", ToolType.shovel);

Recipes.addShaped({id: ItemID.jadeShovel, count: 1, data: 0}, [
    "a",
    "b",
    "b"
], ["a", ItemID.jade, 0, "b", 280, 0]);

//pickaxe

IDRegistry.genItemID("jadePickaxe");
Item.createItem("jadePickaxe", "Jade Pickaxe", {name: "jade_pickaxe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("jade_pickaxe", {durability: 1101, level: 4, efficiency: 8, damage: 5, enchantability: 14});
ToolAPI.setTool(ItemID.jadePickaxe, "jade_pickaxe", ToolType.pickaxe);

Recipes.addShaped({id: ItemID.jadePickaxe, count: 1, data: 0}, [
    "aaa",
    " b ",
    " b "
], ["a", ItemID.jade, 0,  "b", 280, 0]);

//axe

IDRegistry.genItemID("jadeAxe");
Item.createItem("jadeAxe", "Jade Axe", {name: "jade_axe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("jade_axe", {durability: 1101, level: 4, efficiency: 8, damage: 9, enchantability: 14});
ToolAPI.setTool(ItemID.jadeAxe, "jade_axe", ToolType.axe);

Recipes.addShaped({id: ItemID.jadeAxe, count: 1, data: 0}, [
    "aa",
    "ab",
    " b"
], ['a', ItemID.jade, 0, 'b', 280, 0]);

//hoe

IDRegistry.genItemID("jadeHoe");
Item.createItem("jadeHoe", "Jade Hoe", {name: "jade_hoe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("jade_hoe", {durability: 1101, level: 4, efficiency: 8, damage: 1, enchantability: 14});
ToolAPI.setTool(ItemID.jadeHoe, "jade_hoe", ToolType.hoe);

Recipes.addShaped({id: ItemID.jadeHoe, count: 1, data: 0}, [
    "aa",
    " b",
    " b"
], ['a', ItemID.jade, 0, 'b', 280, 0]);