IDRegistry.genItemID("jadeHelmet");
IDRegistry.genItemID("jadeChestplate");
IDRegistry.genItemID("jadeLeggings");
IDRegistry.genItemID("jadeBoots");

Item.createArmorItem("jadeHelmet", "Jade Helmet", {name: "jade_helmet"}, {type: "helmet", armor: 5, durability: 364, texture: "armor/jade_layer_1.png"});
Item.createArmorItem("jadeChestplate", "Jade Chestplate", {name: "jade_chestplate"}, {type: "chestplate", armor: 10, durability: 529, texture: "armor/jade_layer_1.png"});
Item.createArmorItem("jadeLeggings", "Jade Leggings", {name: "jade_leggings"}, {type: "leggings", armor: 8, durability: 496, texture: "armor/jade_layer_2.png"});
Item.createArmorItem("jadeBoots", "Jade Boots", {name: "jade_boots"}, {type: "boots", armor: 5, durability: 430, texture: "armor/jade_layer_1.png"});

Recipes.addShaped({id: ItemID.jadeHelmet, count: 1, data: 0}, [
    "xxx",
    "x x",
    "  "
], ["x", ItemID.jade, 0]);

Recipes.addShaped({id: ItemID.jadeChestplate, count: 1, data: 0}, [
    "x x",
    "xxx",
    "xxx"
], ["x", ItemID.jade, 0]);

Recipes.addShaped({id: ItemID.jadeLeggings, count: 1, data: 0}, [
    "xxx",
    "x x",
    "x x"
], ["x", ItemID.jade, 0]);

Recipes.addShaped({id: ItemID.jadeBoots, count: 1, data: 0}, [
    "   ",
    "x x",
    "x x"
], ["x", ItemID.jade, 0]);