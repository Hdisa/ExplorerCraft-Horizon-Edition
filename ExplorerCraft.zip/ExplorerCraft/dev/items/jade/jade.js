IDRegistry.genItemID("jade");
Item.createItem("jade", "Jade", { name: "jade", meta: 0});