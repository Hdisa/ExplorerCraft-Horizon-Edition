IDRegistry.genItemID("amethyst");
Item.createItem("amethyst", "Amethyst", { name: "amethyst", meta: 0});