IDRegistry.genItemID("amethystHelmet");
IDRegistry.genItemID("amethystChestplate");
IDRegistry.genItemID("amethystLeggings");
IDRegistry.genItemID("amethystBoots");

Item.createArmorItem("amethystHelmet", "Amethyst Helmet", {name: "amethyst_helmet"}, {type: "helmet", armor: 3, durability: 364, texture: "armor/amethyst_layer_1.png"});
Item.createArmorItem("amethystChestplate", "Amethyst Chestplate", {name: "amethyst_chestplate"}, {type: "chestplate", armor: 6, durability: 529, texture: "armor/amethyst_layer_1.png"});
Item.createArmorItem("amethystLeggings", "Amethyst Leggings", {name: "amethyst_leggings"}, {type: "leggings", armor: 6, durability: 496, texture: "armor/amethyst_layer_2.png"});
Item.createArmorItem("amethystBoots", "Amethyst Boots", {name: "amethyst_boots"}, {type: "boots", armor: 3, durability: 430, texture: "armor/amethyst_layer_1.png"});

Recipes.addShaped({id: ItemID.amethystHelmet, count: 1, data: 0}, [
    "xxx",
    "x x",
    "  "
], ["x", ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethystChestplate, count: 1, data: 0}, [
    "x x",
    "xxx",
    "xxx"
], ["x", ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethystLeggings, count: 1, data: 0}, [
    "xxx",
    "x x",
    "x x"
], ["x", ItemID.amethyst, 0]);

Recipes.addShaped({id: ItemID.amethystBoots, count: 1, data: 0}, [
    "   ",
    "x x",
    "x x"
], ["x", ItemID.amethyst, 0]);