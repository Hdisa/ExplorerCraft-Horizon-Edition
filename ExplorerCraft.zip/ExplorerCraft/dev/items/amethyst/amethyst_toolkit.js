//sword

IDRegistry.genItemID("amethystSword");
Item.createItem("amethystSword", "Amethyst Sword", {name: "amethyst_sword", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("amethyst_sword", {durability: 751, level: 3, efficiency: 8, damage: 7, enchantability: 14});
ToolAPI.setTool(ItemID.amethystSword, "amethyst_sword", ToolType.sword);

Recipes.addShaped({id: ItemID.amethystSword, count: 1, data: 0}, [
    "a",
    "a",
    "b"
], ["a", ItemID.amethyst, 0, "b", 280, 0]);

//shovel

IDRegistry.genItemID("amethystShovel");
Item.createItem("amethystShovel", "Amethyst Shovel", {name: "amethyst_shovel", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("amethyst_shovel", {durability: 751, level: 3, efficiency: 8, damage: 5.5, enchantability: 14});
ToolAPI.setTool(ItemID.amethystShovel, "amethyst_shovel", ToolType.shovel);

Recipes.addShaped({id: ItemID.amethystShovel, count: 1, data: 0}, [
    "a",
    "b",
    "b"
], ["a", ItemID.amethyst, 0, "b", 280, 0]);

//pickaxe

IDRegistry.genItemID("amethystPickaxe");
Item.createItem("amethystPickaxe", "Amethyst Pickaxe", {name: "amethyst_pickaxe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("amethyst_pickaxe", {durability: 751, level: 3, efficiency: 8, damage: 5, enchantability: 14});
ToolAPI.setTool(ItemID.amethystPickaxe, "amethyst_pickaxe", ToolType.pickaxe);

Recipes.addShaped({id: ItemID.amethystPickaxe, count: 1, data: 0}, [
    "aaa",
    " b ",
    " b "
], ["a", ItemID.amethyst, 0,  "b", 280, 0]);

//axe

IDRegistry.genItemID("amethystAxe");
Item.createItem("amethystAxe", "Amethyst Axe", {name: "amethyst_axe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("amethyst_axe", {durability: 751, level: 3, efficiency: 8, damage: 9, enchantability: 14});
ToolAPI.setTool(ItemID.amethystAxe, "amethyst_axe", ToolType.axe);

Recipes.addShaped({id: ItemID.amethystAxe, count: 1, data: 0}, [
    "aa",
    "ab",
    " b"
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);

//hoe

IDRegistry.genItemID("amethystHoe");
Item.createItem("amethystHoe", "Amethyst Hoe", {name: "amethyst_hoe", meta: 0}, {stack: 1});
ToolAPI.addToolMaterial("amethyst_hoe", {durability: 751, level: 3, efficiency: 8, damage: 1, enchantability: 14});
ToolAPI.setTool(ItemID.amethystHoe, "amethyst_hoe", ToolType.hoe);

Recipes.addShaped({id: ItemID.amethystHoe, count: 1, data: 0}, [
    "aa",
    " b",
    " b"
], ['a', ItemID.amethyst, 0, 'b', 280, 0]);