IDRegistry.genItemID("wizardHat");
Item.createArmorItem("wizardHat", "Wizard Hat", {name: ""}, {type: "helmet", armor: 2, durability: 149, texture: "armor/wizard_hat_layer_1.png"});