IDRegistry.genBlockID("jadeOre");
Block.createBlock("jadeOre", [ 
  {name: "Jade Ore", texture: [["ore_jade", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.jadeOre, "stone", 2);
Block.setDestroyTime(BlockID.jadeOre, 7);
Block.setDestroyLevel("jadeOre", 2);
Block.registerDropFunction("jadeOre", function(coords, blockID, blockData, level, enchant){
	if(level > 2){
		if(enchant.silk){
			return [[blockID, 1, 0]];
		}
		var drop = [[ItemID.jade, 1, 0]];
		if(Math.random() < enchant.fortune/2 - 1/3){drop.push(drop[0]);}
		ToolAPI.dropOreExp(coords, 2, 5, enchant.experience);
		return drop;
	}
	return [];
}, 3);
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
  for(var i = 0; i < 5; i++){
      var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 10);
          GenerationUtils.generateOre(coords.x, coords.y, coords.z, BlockID.jadeOre, 0, 5);
  }
});