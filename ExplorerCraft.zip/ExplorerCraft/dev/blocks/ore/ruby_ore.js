IDRegistry.genBlockID("rubyOre");
Block.createBlock("rubyOre", [ 
  {name: "Ruby Ore", texture: [["ore_ruby", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.rubyOre, "stone", 2);
Block.setDestroyTime(BlockID.rubyOre, 6);
Block.setDestroyLevel("rubyOre", 2);
Block.registerDropFunction("rubyOre", function(coords, blockID, blockData, level, enchant){
	if(level > 2){
		if(enchant.silk){
			return [[blockID, 1, 0]];
		}
		var drop = [[ItemID.ruby, 1, 0]];
		if(Math.random() < enchant.fortune/2 - 1/3){drop.push(drop[0]);}
		ToolAPI.dropOreExp(coords, 2, 5, enchant.experience);
		return drop;
	}
	return [];
}, 3);
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
  for(var i = 0; i < 5; i++){
      var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 15);
          GenerationUtils.generateOre(coords.x, coords.y, coords.z, BlockID.rubyOre, 0, 5);
  }
});