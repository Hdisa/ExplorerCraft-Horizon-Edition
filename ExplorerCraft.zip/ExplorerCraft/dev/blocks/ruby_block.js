IDRegistry.genBlockID("rubyBlock");
Block.createBlock("rubyBlock", [
     {name: "Ruby Block", texture: [["block_ruby", 0]], inCreative: true}]);

Recipes.addShaped({id: BlockID.rubyBlock, count: 1, data: 0}, [
    "aaa",
    "aaa",
    "aaa"
], ["a", ItemID.ruby, 0]);