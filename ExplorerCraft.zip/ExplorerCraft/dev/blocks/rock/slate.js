//slate
IDRegistry.genBlockID("slate");
Block.createBlock("slate", [ 
  {name: "Slate", texture: [["slate", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.slate, "stone", 2);
Block.setDestroyTime(BlockID.slate, 5);
Block.setDestroyLevel("slate", 2);
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
  for(var i = 0; i < 15; i++){
      var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 23, 113);
          GenerationUtils.generateOre(coords.x, coords.y, coords.z, BlockID.slate, 0, 15);
  }
});

//slate polished
IDRegistry.genBlockID("slatePolished");
Block.createBlock("slatePolished", [ 
  {name: "Polished Slate", texture: [["slate_polished_top", 0], ["slate_polished_top", 0], ["slate_polished_side", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.slatePolished, count: 1, data: 0}, [
    {id: BlockID.slate, data: 0}
]);

//slate bricks
IDRegistry.genBlockID("slateBricks");
Block.createBlock("slateBricks", [ 
  {name: "Slate Bricks", texture: [["slate_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.slateBricks, count: 4, data: 0}, [
    "aa",
    "aa"
], ['a', BlockID.slate, 0]);

//slate mossy
IDRegistry.genBlockID("slateMossy");
Block.createBlock("slateMossy", [ 
  {name: "Mossy Slate Bricks", texture: [["slate_mossy", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.slateMossy, count: 1, data: 0}, [
    {id: BlockID.slateBricks, data: 0}, {id: 106, data: 0},
]);

//slate pillar
IDRegistry.genBlockID("slatePillar");
Block.createBlock("slatePillar", [ 
  {name: "Slate Pillar", texture: [["slate_polished_top", 0], ["slate_polished_top", 0], ["slate_pillar", 0], 
["slate_pillar", 0], ["slate_pillar", 0], ["slate_pillar", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.slatePillar, count: 2, data: 0}, [
    "a",
    "a"
], ['a', BlockID.slateBricks, 0]);

//slate tile
IDRegistry.genBlockID("slateTile");
Block.createBlock("slateTile", [ 
  {name: "Slate Tiles", texture: [["slate_tile", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.slateTile, count: 4, data: 0}, [
    "aa",
    "aa"
], ['a', BlockID.slatePolished, 0]);