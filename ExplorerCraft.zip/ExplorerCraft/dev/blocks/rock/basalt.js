//basalt
IDRegistry.genBlockID("basalt");
Block.createBlock("basalt", [ 
  {name: "Basalt", texture: [["basalt", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.basalt, "stone", 2);
Block.setDestroyTime(BlockID.basalt, 5);
Block.setDestroyLevel("basalt", 2);
Block.registerDropFunction("basalt", function(coords, blockID, blockData, level, enchant){
	if(level > 2){
		if(enchant.silk){
			return [[blockID, 1, 0]];
		}
return [[BlockID.basaltCobblestone, 1, 0]]
}
});
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
  for(var i = 0; i < 15; i++){
      var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 75);
          GenerationUtils.generateOre(coords.x, coords.y, coords.z, BlockID.basalt, 0, 15);
  }
});

//basalt cobblestone
IDRegistry.genBlockID("basaltCobblestone");
Block.createBlock("basaltCobblestone", [ 
  {name: "Basalt Cobblestone", texture: [["basalt_cobblestone", 0]], inCreative: true}]);

//basalt polished
IDRegistry.genBlockID("basaltPolished");
Block.createBlock("basaltPolished", [ 
  {name: "Polished Basalt", texture: [["basalt_polished", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.basaltPolished, count: 1, data: 0}, [
    {id: BlockID.basalt, data: 0}
]);

//basalt bricks
IDRegistry.genBlockID("basaltBricks");
Block.createBlock("basaltBricks", [ 
  {name: "Basalt Bricks", texture: [["basalt_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.basaltBricks, count: 4, data: 0}, [
    "aa",
    "aa"
], ['a', BlockID.basalt, 0]);

//basalt mossy
IDRegistry.genBlockID("basaltMossy");
Block.createBlock("basaltMossy", [ 
  {name: "Mossy Basalt Bricks", texture: [["basalt_mossy", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.basaltMossy, count: 1, data: 0}, [
    {id: BlockID.basaltBricks, data: 0}, {id: 106, data: 0},
]);

//basalt cracked
IDRegistry.genBlockID("basaltCracked");
Block.createBlock("basaltCracked", [ 
  {name: "Cracked Basalt Bricks", texture: [["basalt_cracked", 0]], inCreative: true}]);
Recipes.addFurnace(BlockID.basaltBricks, BlockID.basaltCracked, 0);

//basalt pillar
IDRegistry.genBlockID("basaltPillar");
Block.createBlockWithRotation("basaltPillar", [ 
  {name: "Basalt Pillar", texture: [["basalt_polished", 0], ["basalt_polished", 0], ["basalt_pillar", 0], 
["basalt_pillar", 0], ["basalt_pillar", 0], ["basalt_pillar", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.basaltPillar, count: 2, data: 0}, [
    "a",
    "a"
], ['a', BlockID.basaltSlab, 0]);

//basalt brick slab INDEV
IDRegistry.genBlockID("basaltSlab");
Block.createBlock("basaltSlab", [ 
  {name: "Basalt Brick Slab", texture: [["basalt_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.basaltSlab, count: 6, data: 0}, [
    "aaa"
], ['a', BlockID.basaltBricks, 0]);
Block.setShape(BlockID.basaltSlab,0,0,0,1,0.5,1);
/*
//basalt brick stairs INDEV
IDRegistry.genBlockID("basaltStairs");
Block.createBlock("basaltStairs", [ 
  {name: "Basalt Brick Stairs", texture: [["basalt_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.basaltStairs, count: 4, data: 0}, [
    "a  ",
    "aa ",
    "aaa"
], ['a', BlockID.basaltBricks, 0]);
Block.setShape(BlockID.basaltStairs,0,0,0,1,0.5,1);
*/