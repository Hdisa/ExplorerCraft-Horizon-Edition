IDRegistry.genBlockID("marble");
Block.createBlock("marble", [ 
  {name: "Marble", texture: [["marble", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.marble, "stone", 2);
Block.setDestroyTime(BlockID.marble, 5);
Block.setDestroyLevel("marble", 2);
Callback.addCallback("GenerateChunkUnderground", function(chunkX, chunkZ){
  for(var i = 0; i < 15; i++){
      var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 50);
          GenerationUtils.generateOre(coords.x, coords.y, coords.z, BlockID.marble, 0, 15);
  }
});

//marble polished
IDRegistry.genBlockID("marblePolished");
Block.createBlock("marblePolished", [ 
  {name: "Polished Marble", texture: [["marble_polished", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.marblePolished, count: 1, data: 0}, [
    {id: BlockID.marble, data: 0}
]);

//marble bricks
IDRegistry.genBlockID("marbleBricks");
Block.createBlock("marbleBricks", [ 
  {name: "Marble Bricks", texture: [["marble_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.marbleBricks, count: 4, data: 0}, [
    "aa",
    "aa"
], ['a', BlockID.marble, 0]);

//marble mossy
IDRegistry.genBlockID("marbleMossy");
Block.createBlock("marbleMossy", [ 
  {name: "Mossy Marble Bricks", texture: [["marble_mossy", 0]], inCreative: true}]);
Recipes.addShapeless({id: BlockID.marbleMossy, count: 1, data: 0}, [
    {id: BlockID.marbleBricks, data: 0}, {id: 106, data: 0},
]);

//marble cracked
IDRegistry.genBlockID("marbleCracked");
Block.createBlock("marbleCracked", [ 
  {name: "Cracked Marble Bricks", texture: [["marble_cracked", 0]], inCreative: true}]);
Recipes.addFurnace(BlockID.marbleBricks, BlockID.marbleCracked, 0);

//marble pillar
IDRegistry.genBlockID("marblePillar");
Block.createBlock("marblePillar", [ 
  {name: "Marble Pillar", texture: [["marble_polished", 0], ["marble_polished", 0], ["marble_pillar", 0], 
["marble_pillar", 0], ["marble_pillar", 0], ["marble_pillar", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.marblePillar, count: 2, data: 0}, [
    "a",
    "a"
], ['a', BlockID.marbleSlab, 0]);

//marble brick slab INDEV
IDRegistry.genBlockID("marbleSlab");
Block.createBlock("marbleSlab", [ 
  {name: "Marble Brick Slab", texture: [["marble_bricks", 0]], inCreative: true}]);
Recipes.addShaped({id: BlockID.marbleSlab, count: 6, data: 0}, [
    "aaa",
], ['a', BlockID.marbleBricks, 0]);
Block.setShape(BlockID.marbleSlab,0,0,0,1,0.5,1);
/*
//marble brick stairs INDEV
IDRegistry.genBlockID("marbleStairs");
Block.createBlock("marbleStairs", [ 
  {name: "Marble Brick Stairs", texture: [["marble_bricks", 0]], inCreative: true}], BLOCK_RENDER_STAIRS);
Recipes.addShaped({id: BlockID.marbleStairs, count: 4, data: 0}, [
    "a  ",
    "aa ",
    "aaa"
], ['a', BlockID.marbleBricks, 0]);
*/