IDRegistry.genBlockID("jadeBlock");
Block.createBlock("jadeBlock", [
     {name: "Jade Block", texture: [["block_jade", 0]], inCreative: true}]);

Recipes.addShaped({id: BlockID.jadeBlock, count: 1, data: 0}, [
    "aaa",
    "aaa",
    "aaa"
], ["a", ItemID.jade, 0]);