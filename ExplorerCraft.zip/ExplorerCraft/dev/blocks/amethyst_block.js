IDRegistry.genBlockID("amethystBlock");
Block.createBlock("amethystBlock", [
     {name: "Amethyst Block", texture: [["block_amethyst", 0]], inCreative: true}]);

Recipes.addShaped({id: BlockID.amethystBlock, count: 1, data: 0}, [
    "aaa",
    "aaa",
    "aaa"
], ["a", ItemID.amethyst, 0]);