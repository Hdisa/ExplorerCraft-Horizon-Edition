IDRegistry.genBlockID("bambooPlanks");
Block.createBlock("bambooPlanks", [
     {name: "Bamboo Planks", texture: [["bamboo_planks", 0]], inCreative: false}]);