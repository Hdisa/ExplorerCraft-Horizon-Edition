IDRegistry.genBlockID("bambooPlanksVertical");
Block.createBlock("bambooPlanksVertical", [
     {name: "Bamboo Wall", texture: [["bamboo_planks_vertical", 0]], inCreative: false}]);
